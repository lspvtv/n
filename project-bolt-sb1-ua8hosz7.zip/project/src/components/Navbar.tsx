import React from 'react';
import { Link } from 'react-router-dom';
import { Gift, Users, Plus, LogIn } from 'lucide-react';
import { useStore } from '../store/useStore';

function Navbar() {
  const { user } = useStore();

  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Gift className="w-8 h-8 text-purple-600" />
            <span className="text-xl font-semibold text-gray-800">BirthdayAI</span>
          </Link>
          
          <div className="flex items-center space-x-4">
            {user ? (
              <>
                <Link to="/people" className="flex items-center space-x-1 text-gray-600 hover:text-purple-600">
                  <Users className="w-5 h-5" />
                  <span>People</span>
                </Link>
                <Link to="/add-person" className="flex items-center space-x-1 text-gray-600 hover:text-purple-600">
                  <Plus className="w-5 h-5" />
                  <span>Add Person</span>
                </Link>
                <div className="text-sm text-gray-500">
                  Credits: {user.credits}
                </div>
              </>
            ) : (
              <Link to="/auth" className="flex items-center space-x-1 text-gray-600 hover:text-purple-600">
                <LogIn className="w-5 h-5" />
                <span>Sign In</span>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar